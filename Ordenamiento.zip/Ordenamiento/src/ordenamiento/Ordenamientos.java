package ordenamiento;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Ordenamientos {
    private final double[] numbers;
    private final int size;
    
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el tamaño del arreglo: ");
        int size = scanner.nextInt();

        Ordenamientos ordenamientos = new Ordenamientos(size);

        System.out.println("Arreglo original:");
        ordenamientos.printNumbers();

        ordenamientos.ordenarConBubbleSort();
        
    }

    public Ordenamientos(int size) {
        this.size = size;
        numbers = new double[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            numbers[i] = random.nextDouble();
        }
    }

    public void bubbleSort() {
        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - i - 1; j++) {
                if (numbers[j] > numbers[j+1]) {
                    double temp = numbers[j];
                    numbers[j] = numbers[j+1];
                    numbers[j+1] = temp;
                }
            }
        }
    }

    public void insertionSort() {
        for (int i = 1; i < size; i++) {
            double key = numbers[i];
            int j = i - 1;
            while (j >= 0 && numbers[j] > key) {
                numbers[j+1] = numbers[j];
                j--;
            }
            numbers[j+1] = key;
        }
    }

    public void selectionSort() {
         for (int i = 0; i < size - 1; i++) {
            int minIndex = i;
            for (int j = i+1; j < size; j++) {
                if (numbers[j] < numbers[minIndex]) {
                    minIndex = j;
                }
            }
            double temp = numbers[minIndex];
            numbers[minIndex] = numbers[i];
            numbers[i] = temp;
        }
    }

    public void mergeSort() {
        mergeSort(0, size-1);
    }

    private void mergeSort(int low, int high) {
        if (low < high) {
            int mid = (low + high) / 2;
            mergeSort(low, mid);
            mergeSort(mid+1, high);
            merge(low, mid, high);
        }
    }

    private void merge(int low, int mid, int high) {
         double[] temp = new double[size];
        for (int i = low; i <= high; i++) {
            temp[i] = numbers[i];
        }
        int i = low;
        int j = mid + 1;
        int k = low;
        while (i <= mid && j <= high) {
            if (temp[i] <= temp[j]) {
                numbers[k] = temp[i];
                i++;
            } else {
                numbers[k] = temp[j];
                j++;
            }
            k++;
        }
        while (i <= mid) {
            numbers[k] = temp[i];
            k++;
            i++;
        }
    }

    public void printNumbers() {
        System.out.println(Arrays.toString(numbers));
    }

    // Nuevas funciones agregadas

    public void ordenarConBubbleSort() {
        bubbleSort();
        System.out.println("\nArreglo ordenado con Bubble Sort:");
        printNumbers();
    }

    public void ordenarConInsertionSort() {
        insertionSort();
        System.out.println("\nArreglo ordenado con Insertion Sort:");
        printNumbers();
    }

    public void ordenarConSelectionSort() {
        selectionSort();
        System.out.println("\nArreglo ordenado con Selection Sort:");
        printNumbers();
    }

    public void ordenarConMergeSort() {
        mergeSort();
        System.out.println("\nArreglo ordenado con Merge Sort:");
        printNumbers();
    }

    
}