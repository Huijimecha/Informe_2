package ordenamiento;

import java.util.Scanner;

public class Matrices {
    private int filas , columnas;
    private int[][] matriz;
    
    public Matrices(int filas, int columnas){
        this.filas = filas;
        this.columnas = columnas;
        this.matriz = new int[filas][columnas];
    }

    public void cargarMatriz(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("\t\tIngrese los elementos de la matriz\n\n");
        
        for (int i = 0; i < filas ; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print("Ingrese el elementos de la posicion : \n");
                System.out.print("["+i+"] ["+j+"] :   ");
                matriz[i][j]= scanner.nextInt();
            }
        }
    }
    
    public void ImprimirMatriz(){
        
        for (int i = 0; i < filas ; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print("\t"+ matriz[i][j]);
            }
            System.out.println();
        }
        
    }
    
    
    public static void main(String[] args) {

        int TipoOperacion=0;
        int constante=0;
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("\t\t Operaciones Disponibles \n ");
        System.out.print("\t\t Operaciones Disponibles\n");
        System.out.print("\t\t ( 1 ) Suma de matrices\n");
        System.out.print("\t\t ( 2 ) producto de matrices\n");
        System.out.print("\t\t ( 3 ) producto de un escalar con una matriz.\n");
        System.out.print("\t\t ( 4 ) Traspuesta de una matriz \n "); 
        
        System.out.print("Ingrese el número de filas: ");
        int filas = scanner.nextInt();

        System.out.print("Ingrese el número de columnas: ");
        int columnas = scanner.nextInt();

        Matrices matriz1=new Matrices(filas,columnas);
        matriz1.cargarMatriz();
        
        Matrices matriz2=null;
        
        do{
            System.out.print("\nIngrese la operación deseada (1-4, 0 para salir): ");
            TipoOperacion = scanner.nextInt();
       
            switch(TipoOperacion){
                case 1: 
                    System.out.println("\n\t\tLa suma es:");
                    matriz2 = new Matrices(filas, columnas);
                    matriz2.cargarMatriz();
                    Matrices resultadoSuma = sumarMatrices(matriz1, matriz2);
                    resultadoSuma.ImprimirMatriz();

                break;
                case 2: 
                    System.out.println("\n\t\tEl producto es:");
                    System.out.print("Ingrese el número de filas de la segunda matriz: ");
                    int filas2 = scanner.nextInt();
                    System.out.print("Ingrese el número de columnas de la segunda matriz: ");
                    int columnas2 = scanner.nextInt();
                    matriz2 = new Matrices(filas2, columnas2);
                    matriz2.cargarMatriz();
                    Matrices resultadoProducto = multiplicarMatrices(matriz1, matriz2);
                    resultadoProducto.ImprimirMatriz();

                break;
                case 3: 
                    System.out.print("Ingrese el Escalar: ");
                    int escalar = scanner.nextInt();
                    Matrices resultadoEscalar = multiplicarPorEscalar(matriz1 , escalar);
                    resultadoEscalar.ImprimirMatriz();
                break;
                case 4: 
                    Matrices traspuesta = matriz1.traspuesta();
                    System.out.println("");
                    traspuesta.ImprimirMatriz();
                break;
                case 0: 
                    System.out.println("\t\tSaliendo Del Programa ");
                break;
                default:
                    System.out.println("Opción invalida. Intente nuevamente.\n");
                break;

            }
        }while(TipoOperacion!=0);
    }
        
    public static Matrices sumarMatrices(Matrices matriz1, Matrices matriz2) {
        int filas = matriz1.filas;
        int columnas = matriz1.columnas;
        Matrices resultado = new Matrices(filas, columnas);

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                resultado.matriz[i][j] = matriz1.matriz[i][j] + matriz2.matriz[i][j];
            }
        }

        return resultado;
    }
    
    public static Matrices multiplicarMatrices(Matrices matriz1, Matrices matriz2) {
        
        int filas1= matriz1.filas;
        int columnas1= matriz1.columnas;
        int filas2= matriz2.filas;
        int columnas2= matriz2.columnas;
        
        if (columnas1 != filas2) {
            System.out.println("No se pueden multiplicar las matrices debido a que sus dimensiones son incompatibles.");        
        }
        
        Matrices resultado = new Matrices(filas1, columnas2);
        
        for (int i = 0; i < filas1; i++) {
            for (int j = 0; j < columnas2; j++) {
                 {
                    resultado.matriz[i][j] =matriz1.matriz[i][j] * matriz2.matriz[i][j]; 
                }
            }
        }
        
        return resultado;
    }
    
    public static Matrices multiplicarPorEscalar(Matrices matriz1, int escalar){
        int filas = matriz1.filas;
        int columnas = matriz1.columnas;
        Matrices resultado = new Matrices(filas, columnas);
        
        
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                resultado.matriz[i][j] = matriz1.matriz[i][j] * escalar;    
            }
        }
        
        return resultado;
    }
    
    public Matrices traspuesta(){
        int filas = this.columnas;
        int columnas = this.filas;
        
        Matrices resultado = new Matrices(filas, columnas);
        
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                resultado.matriz[i][j] = this.matriz[j][i];    
            }
        }
        
        return resultado;
    }
}